﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using StoredProc.Data;
using StoredProc.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoredProc.Controllers
{
    public class CarController : Controller
    {
        public StoredProcDbContext _context;
        public IConfiguration _config { get; }

        public CarController(StoredProcDbContext context,IConfiguration config)
        {
            this._context = context;
            this._config = config;
        }


        public IActionResult Index()
        {
            return View();
        }

        public IEnumerable<Car> SearchResult()
        {
            var result = _context.Car
                .FromSqlRaw<Car>("spSearchCars")
                .ToList();

            return result;
        }

        [HttpGet]
        public IActionResult DynamicSQL()
        {
            string connectionStr = _config.GetConnectionString("DefaultConnection");

            using (SqlConnection con = new SqlConnection(connectionStr))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "dbo.spSearchCars";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                List<Car> model = new List<Car>();
                while (sdr.Read())
                {
                    var details = new Car();
                    details.brand = sdr["brand"].ToString();
                    details.color = sdr["color"].ToString();
                    details.price = Convert.ToInt32(sdr["price"]);
                    model.Add(details);
                }
                return View(model);
            }
        }

        /// <summary>
        /// SearchPageWithoutDynamicSQL
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IActionResult DynamicSQL(string brand, string color, int price)
        {
            string connectionStr = _config.GetConnectionString("DefaultConnection");

            using (SqlConnection con = new SqlConnection(connectionStr))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "dbo.spSearchCars";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                if (brand != null)
                {
                    SqlParameter param_fn = new SqlParameter("@brand", brand);
                    cmd.Parameters.Add(param_fn);
                }
                if (color != null)
                {
                    SqlParameter param_ln = new SqlParameter("@color", color);
                    cmd.Parameters.Add(param_ln);
                }
                if (price != 0)
                {
                    SqlParameter param_s = new SqlParameter("@price", price);
                    cmd.Parameters.Add(param_s);
                }
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                List<Car> model = new List<Car>();
                while (sdr.Read())
                {
                    var details = new Car();
                    details.brand = sdr["brand"].ToString();
                    details.color = sdr["color"].ToString();
                    details.price = Convert.ToInt32(sdr["price"]);
                    model.Add(details);
                }
                return View(model);
            }
        }

        [HttpGet]
        public IActionResult SearchWithDynamics()
        {
            string connectionStr = _config.GetConnectionString("DefaultConnection");

            using (SqlConnection con = new SqlConnection(connectionStr))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "dbo.spSearchCars";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                List<Car> model = new List<Car>();
                while (sdr.Read())
                {
                    var details = new Car();
                    details.brand = sdr["brand"].ToString();
                    details.color = sdr["color"].ToString();
                    details.price = Convert.ToInt32(sdr["price"]);
                    model.Add(details);
                }
                return View(model);
            }
        }

        [HttpPost]
        public IActionResult SearchWithDynamics(string brand, string color, int price)
        {
            string connectionStr = _config.GetConnectionString("DefaultConnection");

            using (SqlConnection con = new SqlConnection(connectionStr))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "dbo.spSearchCars";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                StringBuilder stringBuilder = new StringBuilder("Select * from Cars where 1 = 1");

                if (brand != null)
                {
                    SqlParameter param_fn = new SqlParameter("@brand", brand);
                    cmd.Parameters.Add(param_fn);
                }
                if (color != null)
                {
                    SqlParameter param_ln = new SqlParameter("@color", color);
                    cmd.Parameters.Add(param_ln);
                }
                if (price != 0)
                {
                    SqlParameter param_s = new SqlParameter("@price", price);
                    cmd.Parameters.Add(param_s);
                }
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                List<Car> model = new List<Car>();
                while (sdr.Read())
                {
                    var details = new Car();
                    details.brand = sdr["brand"].ToString();
                    details.color = sdr["color"].ToString();
                    details.price = Convert.ToInt32(sdr["price"]);
                    model.Add(details);
                }
                return View(model);
            }
        }


        /// <summary>
        /// DynamicSQLInStoredProcedure
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult DynamicSQLInStoredProcedure()
        {
            string connectionStr = _config.GetConnectionString("DefaultConnection");

            using (SqlConnection con = new SqlConnection(connectionStr))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "dbo.spSearchCarsGoodDynamicSQL";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                List<Car> model = new List<Car>();
                while (sdr.Read())
                {
                    var details = new Car();
                    details.brand = sdr["brand"].ToString();
                    details.color = sdr["color"].ToString();
                    details.price = Convert.ToInt32(sdr["price"]);
                    model.Add(details);
                }
                return View(model);
            }
        }


        /// <summary>
        /// DynamicSQLInStoredProcedure
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public IActionResult DynamicSQLInStoredProcedure(string brand, string color, int price)
        {
            string connectionStr = _config.GetConnectionString("DefaultConnection");

            using (SqlConnection con = new SqlConnection(connectionStr))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "dbo.spSearchCarsGoodDynamicSQL";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                if (brand != null)
                {
                    SqlParameter param_fn = new SqlParameter("@brand", brand);
                    cmd.Parameters.Add(param_fn);
                }
                if (color != null)
                {
                    SqlParameter param_ln = new SqlParameter("@color", color);
                    cmd.Parameters.Add(param_ln);
                }
                if (price != 0)
                {
                    SqlParameter param_s = new SqlParameter("@price", price);
                    cmd.Parameters.Add(param_s);
                }
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                List<Car> model = new List<Car>();
                while (sdr.Read())
                {
                    var details = new Car();
                    details.brand = sdr["brand"].ToString();
                    details.color = sdr["color"].ToString();
                    details.price = Convert.ToInt32(sdr["price"]);
                    model.Add(details);
                }
                return View(model);
            }
        }
    }
}
