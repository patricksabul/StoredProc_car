﻿using System.ComponentModel.DataAnnotations;

namespace StoredProc.Models
{
    public class Car
    {
        [Key]
        public int id { get; set; }
        public string brand { get; set; }
        public string color { get; set; }
        public int price { get; set; }
    }
}
